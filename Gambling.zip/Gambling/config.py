# config.py

import random
from flask import session


# 難易度設定
DIFFICULTY_CONFIG = {
    'easy':      {'luck_multiplier': 1.0,  'odds': 1.2},
    'normal':    {'luck_multiplier': 0.5,  'odds': 1.5},
    'hard':      {'luck_multiplier': 0.2,  'odds': 2.0},
    'veryhard':  {'luck_multiplier': 0.05, 'odds': 3.0},
    'nightmare': {'luck_multiplier': 0.01, 'odds': 5.0},
}

# 解放コスト（難易度）
DIFFICULTY_UNLOCK_COST = {
    'normal':    150000,
    'hard':      2000000,
    'veryhard':  80000000,
    'nightmare': 1000000000,
}

# 解放コスト（ゲーム）
GAME_UNLOCK_COST = {
    'fx':        800000,
    'scratch':   5000000,
    'poker':     120000000,
}

# アイテム設定
ITEM_CONFIG = {
    'cheap':     {'price': 10000,   'bonus': 1},
    'normal':    {'price': 40000,  'bonus': 5},
    'expensive': {'price': 100000, 'bonus': 30},
}

def item_config():
    luck = session['luck']/20
    scale = round(luck**(4/5), 1)
    adjusted = {}
    for key, cfg in ITEM_CONFIG.items():
        adjusted[key] = {
            'price': round(int(cfg['price'] * scale), -3),
            'bonus': cfg['bonus']
        }
    return adjusted

def calc_luck():
    """実質運を計算（1000分率ベース）"""
    base = session.get('luck', 500)
    diff = session.get('difficulty', 'easy')
    mult = DIFFICULTY_CONFIG[diff]['luck_multiplier']
    game = session.get('game')
    # ゲームごとの実質運上限
    if game == 'highlow':
        max_l = 600
    elif game == 'scratch':
        max_l = 800
    else:
        max_l = 700
    return min(int(base * mult), max_l)