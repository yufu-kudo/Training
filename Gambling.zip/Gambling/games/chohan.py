# games/chohan.py

from flask import Blueprint, render_template, request, session, redirect, url_for
import random
from config import DIFFICULTY_CONFIG, calc_luck

chohan_bp = Blueprint('chohan', __name__, template_folder='../templates/chohan')

@chohan_bp.route('/lobby')
def lobby():
    luck = calc_luck()
    odds = DIFFICULTY_CONFIG[session['difficulty']]['odds']
    return render_template(
        'chohan/lobby.html',   # ← ここをサブフォルダ付きに
        money=session['money'],
        debt=session['debt'],
        luck=luck,
        odds=odds
    )

@chohan_bp.route('/play')
def play():
    # dice は直前の play_submit で session に入れておく
    dice = session.pop('dice', None)
    hl_error = session.pop('hl_error', None)
    result   = session.pop('result', None)
    luck     = calc_luck()
    odds     = DIFFICULTY_CONFIG[session['difficulty']]['odds']
    return render_template(
        'play.html',
        money=session['money'],
        debt=session['debt'],
        result=result,
        logs=session.get('logs', []),
        hl_error=hl_error,
        luck=luck,
        odds=odds,
        dice=dice
    )

@chohan_bp.route('/play_submit', methods=['POST'])
def play_submit():
    bet    = int(request.form['bet'])
    session['last_bet'] = bet

    # 残高チェック（1000円未満禁止）
    if bet > session.get('money', 0):
        session['hl_error'] = '⚠残高不足です'
        return redirect(url_for('chohan.play'))

    choice = request.form['choice']   # 'cho' or 'han'
    luck   = calc_luck()
    chance = random.randint(0, 1000)
    # 勝敗判定
    win = (chance <= luck)

    # ── ここからサイコロ画像のための値を生成 ──
    # 勝ちなら「賭けた偶奇」と同じ合計の偶奇、負けなら逆の偶奇を演出
    if win:
        target_parity = 0 if choice == 'cho' else 1
    else:
        target_parity = 1 if choice == 'cho' else 0

    # 合計の偶奇が target_parity になるまで乱数を引く
    while True:
        d1 = random.randint(1, 6)
        d2 = random.randint(1, 6)
        if (d1 + d2) % 2 == target_parity:
            break
    # テンプレートで表示するため session に格納
    session['dice'] = [d1, d2]
    # ── サイコロ画像生成ここまで ──

    # 獲得・減算処理
    if win:
        odds = DIFFICULTY_CONFIG[session['difficulty']]['odds']
        gain = int(round(bet * (odds - 1)))
        session['money'] += gain
        entry = f"+{gain}"
        result_msg = f"勝ち！ +{gain}円"
    else:
        session['money'] -= bet
        entry = f"-{bet}"
        result_msg = f"負け！ -{bet}円"

    # ログ更新
    session['logs'] = [entry] + session.get('logs', [])[:4]

    # ゲームオーバー／クリア判定
    if session['money'] < 1000:
        return redirect(url_for('game_over'))
    if session['money'] >= session['debt']:
        return redirect(url_for('clear'))

    session['result'] = result_msg
    return redirect(url_for('chohan.play'))
