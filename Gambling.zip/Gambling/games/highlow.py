# games/highlow.py

from flask import Blueprint, render_template, request, session, redirect, url_for
import random
from config import DIFFICULTY_CONFIG, calc_luck

highlow_bp = Blueprint('highlow', __name__, template_folder='../templates/highlow')

# トランプのスートリスト
SUITS = ['H', 'D', 'S', 'C']

@highlow_bp.route('/lobby')
def lobby():
    """共通受付同様、運とオッズを渡してロビーを描画"""
    luck = calc_luck()
    odds = DIFFICULTY_CONFIG[session['difficulty']]['odds']
    return render_template(
        'highlow/lobby.html',
        money=session['money'],
        debt=session['debt'],
        luck=luck,
        odds=odds
    )

@highlow_bp.route('/play')
def play():
    """
    play_submit からリダイレクトされた後、
    session から前回の begin/result を取り出して描画。
    勝負前フェーズ用には新しい begin_suit を用意。
    """
    # ── まず、初回あるいはリセット直後に begin_card／begin_suit を初期化 ──
    session.setdefault('begin_card', random.randint(2, 12))
    session.setdefault('begin_suit', random.choice(SUITS))

    # 勝負前フェーズ用のカード情報を取り出し
    begin_card = session['begin_card']
    begin_suit = session['begin_suit']

    # 結果フェーズ用の前回カード（なければ None）
    prev_begin       = session.pop('prev_begin', None)
    prev_begin_suit  = session.pop('prev_begin_suit', None)
    prev_result      = session.pop('prev_result', None)
    prev_result_suit = session.pop('prev_result_suit', None)

    hl_error = session.pop('hl_error', None)
    result   = session.pop('result', None)
    luck     = calc_luck()
    odds     = DIFFICULTY_CONFIG[session['difficulty']]['odds']

    return render_template(
        'highlow/play.html',
        money= session['money'],
        debt=  session['debt'],
        luck=  luck,
        odds=  DIFFICULTY_CONFIG[session['difficulty']]['odds'],

        # ← ここを渡す
        begin_card= begin_card,
        begin_suit= begin_suit,

        prev_begin=       prev_begin,
        prev_begin_suit=  prev_begin_suit,
        prev_result=      prev_result,
        prev_result_suit= prev_result_suit,

        result= result,
        hl_error= hl_error,
        logs= session.get('logs', [])
    )

@highlow_bp.route('/play_submit', methods=['POST'])
def play_submit():
    """High-Low の勝負ロジック＋カード画像情報の準備"""
    bet = int(request.form['bet'])
    session['last_bet'] = bet

    # 残高チェック
    if bet > session.get('money', 0):
        session['hl_error'] = '⚠残高不足です'
        return redirect(url_for('highlow.play'))

    choice = request.form['choice']  # 'high' or 'low'
    luck   = calc_luck()
    begin  = session['begin_card']
    # pre-phase から引き継いだスート
    begin_suit = session.pop('begin_suit', random.choice(SUITS))

    # --- 従来の勝敗＆バイアスロジック省略 ---
    cards   = list(range(1, 14))
    former  = [c for c in cards if c < begin]
    latter  = [c for c in cards if c > begin]
    begin_p = 100 / 13

    if not former or not latter:
        roll = random.uniform(0, 100)
        if roll < begin_p:
            result, refund, win = begin, True, False
        else:
            result, refund, win = random.choice(cards), False, False
    else:
        base_former_p = begin_p * len(former)
        base_latter_p = begin_p * len(latter)
        bet_list      = latter if choice == 'high' else former
        not_list      = former if choice == 'high' else latter
        base_bet_p    = base_latter_p if choice == 'high' else base_former_p
        point = (100 - base_bet_p) / 500 if luck - 500 >= 0 else base_bet_p / 500
        bet_p  = max(5, min(90, base_bet_p + point * (luck - 500)))
        roll   = random.uniform(0, 100)
        if roll < begin_p:
            result, refund, win = begin, True, False
        elif roll < begin_p + bet_p:
            result, refund, win = random.choice(bet_list), False, True
        else:
            result, refund, win = random.choice(not_list), False, False

    # 次回 begin_card の更新
    if result in (1, 13):
        next_begin = random.randint(2, 12)
    else:
        next_begin = result

    # --- ここでカード画像用の情報を session に格納 ---
    # 前回の「始めのカード」とそのスート
    session['prev_begin']      = begin
    session['prev_begin_suit'] = begin_suit
    # 結果のカード数値と、ここで一度だけ決めるスート
    result_suit = random.choice(SUITS)
    session['prev_result']      = result
    session['prev_result_suit'] = result_suit

    # 次ゲームの開始カードは「結果カード」と同じ数値・スートを引き継ぐ
    session['begin_card'] = next_begin
    session['begin_suit'] = result_suit

    # 引き分け時は即リダイレクト
    if refund:
        session['result'] = f"引き分け（無効）: {begin} vs {result}"
        return redirect(url_for('highlow.play'))

    # 勝敗時の所持金更新・ログ
    odds = DIFFICULTY_CONFIG[session['difficulty']]['odds']
    if win:
        gain = int(round(bet * (odds - 1)))
        session['money'] += gain
        entry = f"+{gain}"
        session['result'] = f"勝ち！ {begin} → {result} +{gain}円"
    else:
        session['money'] -= bet
        entry = f"-{bet}"
        session['result'] = f"負け！ {begin} → {result} -{bet}円"

    session['logs'] = [entry] + session.get('logs', [])[:4]

    # ゲームオーバー / クリア判定
    if session['money'] < 1000:
        return redirect(url_for('game_over'))
    if session['money'] >= session['debt']:
        return redirect(url_for('clear'))

    return redirect(url_for('highlow.play'))
