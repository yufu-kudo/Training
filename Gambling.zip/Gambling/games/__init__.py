# games/__init__.py

# Expose the game Blueprints at package level for easy import.
from .chohan import chohan_bp
from .highlow import highlow_bp
from .fx import fx_bp
from .poker import poker_bp

__all__ = [
    "chohan_bp",
    "highlow_bp",
    "fx_bp",
    "poker_bp",
]
