# games/fx.py

from flask import Blueprint, render_template, request, session, redirect, url_for
from config import calc_luck, DIFFICULTY_CONFIG
import random, uuid

fx_bp = Blueprint('fx', __name__, template_folder='../templates/fx')

@fx_bp.route('/')
def index():
    # /fx/ → まずは 受付画面へ
    return redirect(url_for('fx.lobby'))
@fx_bp.route('/lobby')
def lobby():
    """FX 受付画面"""
    fx_error = session.pop('fx_error', None)
    # FX でもグローバル同様に進捗メーターを表示したいなら luck/odds を渡せますが必須ではありません
    luck = calc_luck()
    odds = DIFFICULTY_CONFIG[session['difficulty']]['odds']
    return render_template(
        'fx/lobby.html',
        money=session['money'],
        debt=session['debt'],
        luck=luck,
        odds=odds,
        fx_error=fx_error
    )

@fx_bp.route('/play', methods=['GET'])
def play():
    """FX チャート画面（ゲーム画面）"""
    fx_error = session.pop('fx_error', None)
    session.setdefault('fx_price', random.randint(3000,7000))
    session.setdefault('fx_holdings', [])
    session.setdefault('fx_logs', [])
    return render_template(
        'chart.html',
        money=session['money'],
        debt=session['debt'],
        price=session['fx_price'],
        fx_holdings=session['fx_holdings'],
        fx_logs=session['fx_logs'],
        fx_error=fx_error
    )

@fx_bp.route('/buy', methods=['POST'])
def buy():
    amt   = int(request.form['amount'])
    price = session['fx_price']
    cost  = amt * price
    # 購入後に所持金が1000未満にならないかチェック
    if session['money'] >= cost and session['money'] - cost >= 1000:
        session.pop('fx_error', None)
        session['money'] -= cost
        session['fx_holdings'].append({
            'id': str(uuid.uuid4()),
            'price': price,
            'amount': amt,
            'turns': 5
        })
        _fx_next_turn()
        # 所持金が1000未満ならゲームオーバー
        if session['money'] < 1000:
            return redirect(url_for('game_over'))
    else:
        session['fx_error'] = '⚠残高不足です'
    return redirect(url_for('fx.play'))

@fx_bp.route('/wait', methods=['POST'])
def wait():
    session.pop('fx_error', None)
    # 見送り後に所持金が1000未満にならないかチェック
    if session['money'] - 5000 >= 1000:
        session['money'] -= 5000
        _fx_next_turn()
        if session['money'] < 1000:
            return redirect(url_for('game_over'))
    else:
        session['fx_error'] = '⚠残高不足です'
    return redirect(url_for('fx.play'))

@fx_bp.route('/sell', methods=['POST'])
def sell():
    session.pop('fx_error', None)
    hid      = request.form['id']
    holdings = session['fx_holdings']
    price    = session['fx_price']
    for h in holdings:
        if h['id'] == hid:
            gain = h['amount'] * price
            cost = h['amount'] * h['price']
            session['money'] += gain
            session['fx_logs'] = [str(gain - cost)] + session['fx_logs'][:4]
            holdings.remove(h)
            break
    session['fx_holdings'] = holdings
    # 念のため売却後にもゲームオーバー判定
    if session['money'] < 1000:
        return redirect(url_for('game_over'))
    return redirect(url_for('fx.play'))

def _fx_next_turn():
    p = session.get('fx_price', 5000)

    # 中央値を価格帯に応じて調整
    if p <= 3000:
        mean = p + 150
    elif p >= 8000:
        mean = p - 250
    else:
        mean = p

    new_p = int(random.gauss(mean, 500))
    session['fx_price'] = max(1000, min(10000, new_p))

    new_h = []
    for h in session.get('fx_holdings', []):
        h['turns'] -= 1
        if h['turns'] > 0:
            new_h.append(h)
        else:
            loss = h['amount'] * h['price']
            session['fx_logs'] = [f"-{loss}"] + session['fx_logs'][:4]
    session['fx_holdings'] = new_h
