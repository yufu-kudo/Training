# games/poker.py

from flask import Blueprint, render_template, redirect, url_for, jsonify, request, session
from extensions import socketio
from flask_socketio import join_room, emit
import random, uuid
from itertools import combinations

poker_bp = Blueprint('poker', __name__, template_folder='../templates/poker')

# インメモリのルーム管理
rooms = {}

def _make_shuffled_deck():
    suits = ['H','D','C','S']
    ranks = list(range(1,14))  # 1～13 をそのままファイル名に対応
    deck = [f"{suit}_{rank}" for suit in suits for rank in ranks]
    random.shuffle(deck)
    return deck

# カード文字列 "H_1" → (rank, suit)
def _parse_card(card_str):
    suit, rank = card_str.split('_')
    return int(rank), suit

# 5枚ハンドを評価して比較可能なタプルを返す
def evaluate_five(cards):
    """
    cards: list of 5 strings e.g. ["H_1","D_13",...]
    returns: (hand_rank, tiebreaker1, tiebreaker2, ...)
      hand_rank: 9=ロイヤルフラッシュ,8=ストレートフラッシュ,...,1=ワンペア,0=ハイカード
    """
    ranks, suits = zip(*( _parse_card(c) for c in cards ))
    # ランク頻度でソート [(count, rank),...]
    from collections import Counter
    cnt = Counter(ranks)
    counts = sorted(cnt.items(), key=lambda x:(-x[1],-x[0]))
    # ストレート判定用にエースを14として2,3,4,5,Aもチェック
    uniq = sorted(set(ranks))
    straights = []
    # 標準ストレート
    for seq in combinations(uniq, 5):
        if max(seq)-min(seq)==4 and len(seq)==5:
            straights.append(max(seq))
    # A-5 ストレート (Aを1扱い)
    if set([14,2,3,4,5]).issubset(set(ranks)):
        straights.append(5)
    is_straight = bool(straights)
    top_straight = max(straights) if is_straight else 0
    # フラッシュ判定
    flush_suit = None
    for s, group in Counter(suits).items():
        if group>=5:
            flush_suit = s
    is_flush = bool(flush_suit)
    # ストレートフラッシュ判定
    sf_rank = 0
    if is_flush:
        flush_cards = [r for r,s in zip(ranks,suits) if s==flush_suit]
        uf = sorted(set(flush_cards))
        sf = []
        for seq in combinations(uf,5):
            if max(seq)-min(seq)==4:
                sf.append(max(seq))
        if set([14,2,3,4,5]).issubset(set(flush_cards)):
            sf.append(5)
        if sf:
            sf_rank = max(sf)
    # ロイヤルフラッシュ
    if sf_rank==14:
        return (9,)
    # ストレートフラッシュ
    if sf_rank>0:
        return (8, sf_rank)
    # フォーカード
    if counts[0][1]==4:
        four = counts[0][0]
        kicker = max(r for r in ranks if r!=four)
        return (7, four, kicker)
    # フルハウス
    if counts[0][1]==3 and counts[1][1]>=2:
        three = counts[0][0]
        pair  = counts[1][0]
        return (6, three, pair)
    # フラッシュ
    if is_flush:
        top5 = sorted([r for r,s in zip(ranks,suits) if s==flush_suit], reverse=True)[:5]
        return (5, *top5)
    # ストレート
    if is_straight:
        return (4, top_straight)
    # スリーカード
    if counts[0][1]==3:
        kickers = sorted((r for r in ranks if r!=counts[0][0]), reverse=True)[:2]
        return (3, counts[0][0], *kickers)
    # ツーペア
    if counts[0][1]==2 and counts[1][1]==2:
        high, low = counts[0][0], counts[1][0]
        kicker = max(r for r in ranks if r not in (high,low))
        return (2, high, low, kicker)
    # ワンペア
    if counts[0][1]==2:
        pair = counts[0][0]
        kickers = sorted((r for r in ranks if r!=pair), reverse=True)[:3]
        return (1, pair, *kickers)
    # ハイカード
    top5 = sorted(ranks, reverse=True)[:5]
    return (0, *top5)

def best_hand(seven_cards):
    """７枚から最強の５枚組を探して評価結果を返す"""
    best = None
    for combo in combinations(seven_cards, 5):
        val = evaluate_five(combo)
        if best is None or val>best:
            best = val
    return best

# 役ランク → 日本語名
HAND_NAMES = {
    9: 'ロイヤルフラッシュ',
    8: 'ストレートフラッシュ',
    7: 'フォーカード',
    6: 'フルハウス',
    5: 'フラッシュ',
    4: 'ストレート',
    3: 'スリーカード',
    2: 'ツーペア',
    1: 'ワンペア',
    0: 'ハイカード'
}

# --- app.py引用 ---

@poker_bp.route('/lobby')
def lobby():
    # 現在のユーザーID
    current_uid = session.get('user_id')
    # 「ホストしかいない部屋」かつ「ホストが自分でない部屋」のみを抽出
    pending_rooms = [
        rid for rid, info in rooms.items()
        if len(info.get('players', [])) == 1
           and info['players'][0] != current_uid
    ]
    return render_template(
        'poker/lobby.html',
        money=session['money'],
        debt=session['debt'],
        existing_rooms=pending_rooms
    )

@poker_bp.route('/wait/<room_id>')
def wait(room_id):
    if room_id not in rooms:
        return redirect(url_for('poker.lobby'))
    return render_template(
        'poker/wait.html',
        money=session['money'],
        debt=session['debt'],
        room_id=room_id)

@poker_bp.route('/play/<room_id>')
def play(room_id):
    info = rooms.get(room_id)
    if not info or len(info['players']) < 2:
        return redirect(url_for('poker.lobby'))
    return render_template(
        'poker/play.html', 
        money=session['money'],
        debt=session['debt'],
        room_id=room_id)

# --- WebSocket イベント ---

@socketio.on('connect', namespace='/poker')
def on_connect():
    print(f"[Poker] client connected: {request.sid}")

@socketio.on('create_room', namespace='/poker')
def on_create_room(data):
    uid = session['user_id']
    sid = request.sid

    # 空き部屋があれば reuse／なければ新規作成
    for rid, info in rooms.items():
        if not info['players']:
            room_id = rid
            break
    else:
        room_id = str(uuid.uuid4())[:8]
        rooms[room_id] = {
            'players': [],
            'sids': {},
            'host_ready': False
        }

    # ホストとして参加
    rooms[room_id]['players'].append(uid)
    rooms[room_id]['sids'][uid] = sid
    join_room(room_id)
    emit('room_created', {'room_id': room_id}, room=sid)
    print(f"[Poker] room {room_id} players: {rooms[room_id]['players']}")

@socketio.on('host_rejoin', namespace='/poker')
def on_host_rejoin(data):
    room_id = data.get('room_id')
    uid     = session['user_id']
    sid     = request.sid
    info    = rooms.get(room_id)
    if not info:
        return

    # 常に最新の sid を上書き
    info['sids'][uid] = sid
    info['host_ready'] = True
    join_room(room_id)
    print(f"[Poker] host rejoined room {room_id}: uid={uid} sid={sid}")

@socketio.on('join_room', namespace='/poker')
def on_join(data):
    room_id = data.get('room_id')
    uid     = session.get('user_id')  # Flask session に保存した永続ユーザーID
    sid     = request.sid
    info    = rooms.get(room_id)

    # １）部屋が存在しない → エラー
    if not info:
        emit('error', {'message': 'その部屋は存在しません'}, room=sid)
        print("\n\n 部屋が存在しない \n\n")
        return

    # ２）再接続の場合
    if uid in info['players']:
        # 最新の sid を記録し直して部屋へ再参加
        info['sids'][uid] = sid
        join_room(room_id)
        print("\n\n 再接続の場合 \n\n")

        # ・ホールカード再送
        for player_uid in info['players']:
            target_sid = info['sids'][player_uid]
            emit('deal_hole',
                 {'hole_cards': info['hands'][player_uid]},
                 room=target_sid)

        print("\n\n ホールカード送信 \n\n")
        # ・すでにオープン済みのコミュニティカード再送
        counts = info.get('stage_index', 0)
        if counts > 0:
            emit('reveal',
                 {'cards': info['community'][:counts]},
                 room=sid)
            
        # サーバー側：bets_by_sid を作る
        bets_by_sid = {
            # info['sids'] maps user_id → sid
            sid_val: info['bets'][uid]
            for uid, sid_val in info['sids'].items()
        }

        # ・ベット／ポット状況再送
        emit('update_bets',
            {'bets': bets_by_sid, 'pot': info['pot']},
            room=sid)

        # ・現在のターン通知（次のプレイヤーの sid を送る）
        next_uid = info['turn_order'][info['turn_index']]
        next_sid = info['sids'][next_uid]
        emit('turn',
             {'sid': next_sid},
             room=sid)
        return

    # ３）新規参加
    #    * すでに 2 人揃っている場合は満員エラー
    if len(info['players']) >= 2:
        emit('error', {'message': '部屋が満員です'}, room=sid)
        print("\n\n 満員エラー \n\n")
        return

    # ４）二人目として参加
    info['players'].append(uid)
    info['sids'][uid] = sid
    join_room(room_id)
    print("\n\n 二人目として参加 \n\n")

    # --- ゲーム開始の初期化 ---
    deck = _make_shuffled_deck()
    info['hands']     = { u: [deck.pop(), deck.pop()] for u in info['players'] }
    info['community'] = [deck.pop() for _ in range(5)]
    info['bets']      = { u: 0 for u in info['players'] }
    info['pot']       = 0
    info['turn_order']= list(info['players'])
    info['turn_index']= 0
    info['stage_index']=0
    info['last_action']=None
    

    # マッチング成立通知 → poker.js 側で play 画面に遷移
    emit('matched', {'room_id': room_id}, room=room_id)
    print("\n\n マッチング成立通知 \n\n")



@socketio.on('action', namespace='/poker')
def on_action(data):
    """
    プレイヤーの操作：fold/check/raise
    data = { 'room_id': str, 'action': 'fold'|'check'|'raise' }
    """
    room_id = data.get('room_id')
    uid     = session.get('user_id')    # 永続ユーザーID
    sid     = request.sid
    info    = rooms.get(room_id)
    if not info:
        print("⚠️ その部屋は存在しません")
        return

    # ── １．ターンプレイヤー判定 (user_id ベース) ──
    if uid != info['turn_order'][info['turn_index']]:
        print("⚠️ ターンプレイヤーではありません")
        return

    # ── ２．相手ユーザーID・相手SIDを取得 ──
    other_uid = next(u for u in info['players'] if u != uid)
    other_sid = info['sids'][other_uid]

    action = data.get('action')
    # 直前アクションが 'raise' → この 'check' は実質 'call'
    prev = info.get('last_action')
    notify = action
    if action == 'check' and prev == 'raise':
        notify = 'call'

    # ── ３．相手に直前アクションを通知 ──
    emit('opponent_action', {'action': notify}, room=other_sid)

    # ── ４．操作別ロジック ──
    if action == 'fold':
        # フォールド：まずホールカードを全開示（ショーダウン相当）
        hands = info['hands']
        for player_uid in info['players']:
            target_sid = info['sids'][player_uid]
            # 相手の UID を取得
            opp_uid = next(u for u in info['players'] if u != player_uid)
            emit('showdown',
                 {'opponent_hole': hands[opp_uid]},
                 room=target_sid)

        # ポットを相手に渡してラウンド終了
        pot = sum(info['bets'].values())
        emit('round_end',
             {'winner': other_sid, 'amount': pot},
             room=room_id)
        # ❷ 状態保持
        info['last_winner'] = other_uid
        info['last_loser']  = uid
        # ❸ Loser にだけ「続ける/退出」表示要求
        emit('show_round_buttons_loser', {}, room=info['sids'][uid])
      
        # ポットとベットをリセット
        info['pot'] = 0
        info['bets'] = {u: 0 for u in info['players']}
        print("🃏 fold")
        return

    if action == 'check':
        prev = info.get('last_action')
        # ── (A) レイズ→チェック のコール補填 ──
        if prev == 'raise':
            call_amount = info['bets'][other_uid] - info['bets'][uid]
            info['bets'][uid] += call_amount
            session['money'] -= call_amount
            session.modified = True
            emit('update_session_money', {'money': session['money']}, room=sid)

            info['pot'] += call_amount
            bets_by_sid = {u_sid: info['bets'][u]
                           for u, u_sid in info['sids'].items()}
            emit('update_bets', {'bets': bets_by_sid, 'pot': info['pot']},
                 room=room_id)
            emit('money_delta', {'delta': -call_amount}, room=sid)
        # ── (B) サイクル更新／ショーダウン判定 ──
        if prev in ('check', 'raise') and prev != 'revealed':
            stage = info.get('stage_index', 0)
            if stage < 3:
                # コミュニティカード開示
                counts = [3, 4, 5][stage]
                emit('reveal',
                     {'cards': info['community'][:counts]},
                     room=room_id)
                info['stage_index'] += 1
                # 新サイクルは必ずプレイヤー１から
                info['turn_index'] = 0
                first_uid = info['turn_order'][0]
                print(f'\n\n{info['sids'][first_uid]}\n{room_id}\n\n')
                emit('turn',
                     {'sid': info['sids'][first_uid]},
                     room=room_id)
                # このフェーズでは再度 here に入らないようマーク
                info['last_action'] = 'revealed'
                return
            else:
                # ショーダウン：勝敗判定＆ポット精算
                hands = info['hands']
                community = info['community']
                # まず各自の 7 枚からベスト 5 枚を評価
                results = {u: best_hand(hands[u] + community)
                           for u in info['players']}
                # 役名マッピング
                name_map = {u: HAND_NAMES[results[u][0]] for u in info['players']}
                # 勝者・敗者決定
                u1, u2 = info['players']
                # 1) 比較
                if  results[u1] >  results[u2]:
                    winner_uid = u1
                    loser_uid  = u2
                    is_tie = False
                elif results[u2] >  results[u1]:
                    winner_uid = u2
                    loser_uid  = u1
                    is_tie = False
                else:
                    # 引き分け
                    winner_uid = None
                    loser_uid  = None
                    is_tie     = True

                # 各プレイヤーに相手のホールカード＆手役名を個別送信
                for player_uid in info['players']:
                    target_sid = info['sids'][player_uid]
                    opp_uid    = loser_uid if player_uid == winner_uid else winner_uid
                    emit('showdown',
                         {
                           'opponent_hole': hands[opp_uid],
                           'self_hand':     name_map[player_uid],
                           'opponent_hand': name_map[opp_uid]
                         },
                         room=target_sid)

                # 2) ポット精算
                pot = sum(info['bets'].values())
                if not is_tie:
                    # ❶ ラウンド終了通知
                    emit('round_end',
                         {'winner': info['sids'][winner_uid], 'amount': pot},
                         room=room_id)
                    # ❷ 状態保持
                    info['last_winner'] = winner_uid
                    info['last_loser']  = loser_uid
                    # ❸ Loser にだけ「続ける/退出」表示要求
                    emit('show_round_buttons_loser', {},
                         room=info['sids'][loser_uid])
                else:
                    # 引き分け：半額ずつ返却
                    half = pot // 2
                    emit('round_end',
                         { 'winner': None,     # 取り分けキー無し
                           'amount':  pot,
                           'tie':     True,
                           'half':    half },
                         room=room_id)

                # ラウンド後リセット
                info['pot']         = 0
                info['bets']        = {u:0 for u in info['players']}
                info['stage_index'] = 0
                info['last_action'] = None
                return
                
            # サイクル更新後は last_action をクリアしておく
            info['last_action'] = None
            return

        # ── (C) 上記以外：通常のチェック → 相手へターン交代 ──
        info['turn_index'] = (info['turn_index'] + 1) % 2
        next_uid = info['turn_order'][info['turn_index']]
        emit('turn',
             {'sid': info['sids'][next_uid]},
             room=room_id)
        info['last_action'] = 'check'
        print("✔️ initial check")
        return


    if action == 'raise':
        # レイズ：相手のベット＋10000 を新しい自分のベットとする
        new_bet = min(info['bets'][other_uid] + 10000, 100000)
        delta   = new_bet - info['bets'][uid]
        info['bets'][uid] = new_bet
        info['pot']      += delta
        # 所持金連動
        session['money'] -= delta
        session.modified = True
        emit('update_session_money', {'money': session['money']}, room=sid)
        # レイズ分 delta を通知
        emit('money_delta', {'delta': -delta}, room=sid)
        
        # クライアントが socket.id で参照できるよう SID キーに変換
        bets_by_sid = {
            info['sids'][u]: info['bets'][u]
            for u in info['players']
        }
        emit('update_bets',
             {'bets': bets_by_sid, 'pot': info['pot']},
             room=room_id)

        # ターン交代
        info['turn_index'] = (info['turn_index'] + 1) % len(info['turn_order'])
        next_uid = info['turn_order'][info['turn_index']]
        emit('turn',
             {'sid': info['sids'][next_uid]},
             room=room_id)

        info['last_action'] = 'raise'
        print("⬆️ raise")
        return

    # 想定外のアクション
    print("⚠️ 不明なアクション:", action)

# ブラウザの戻るボタン対策
@socketio.on('disconnect', namespace='/poker')
def on_disconnect():
    sid = request.sid
    # どの user_id の切断か調べる
    for room_id, info in list(rooms.items()):
        # sid が sids の値にあるか？
        # info['sids'] は { user_id: latest_sid }
        for uid, registered_sid in info.get('sids', {}).items():
            if registered_sid != sid:
                continue
            # ・この disconnect は「待機ページに出た後」のものか？
            # ・かつホストだけのまま放置された部屋なら削除
            if info.get('host_ready') \
               and len(info.get('players', [])) == 1 \
               and info['players'][0] == uid:
                rooms.pop(room_id, None)
                print(f"[Poker] removed abandoned room: {room_id}")
            # この room_id は見終わったので内側ループを抜け
            break
        
# 敗者選択権
@socketio.on('loser_ready', namespace='/poker')
def on_loser_ready(data):
    room_id   = data.get('room_id')
    info      = rooms.get(room_id)
    loser_uid = info.get('last_loser')
    winner_uid= info.get('last_winner')
    if not (loser_uid and winner_uid):
        return
    # Winner に「続ける/退出」表示要求
    emit('show_round_buttons_winner', {}, room=info['sids'][winner_uid])

# 両者強制退出
@socketio.on('exit_round', namespace='/poker')
def on_exit_round(data):
    room_id = data.get('room_id')
    # 全員に強制的にロビーへ戻るよう通知
    emit('force_exit', {}, room=room_id)

# ── 続けるボタンで次のラウンドを初期化 ─────────────────────────
@socketio.on('new_round', namespace='/poker')
def on_new_round(data):
    room_id = data.get('room_id')
    info    = rooms.get(room_id)
    if not info or len(info['players']) < 2:
        return

    # 先行後攻を交代 (turn_order を反転)
    info['turn_order'] = info['turn_order'][::-1]

    # 新デッキ生成→再配布
    deck = _make_shuffled_deck()
    info['hands']     = {u: [deck.pop(), deck.pop()] for u in info['players']}
    info['community'] = [deck.pop() for _ in range(5)]

    # ベット／ポットのリセット
    info['bets']        = {u: 0 for u in info['players']}
    info['pot']         = 0
    info['stage_index'] = 0
    info['last_action'] = None

    # ① ホールカード再配布
    for u in info['players']:
        sid = info['sids'][u]
        emit('deal_hole', {'hole_cards': info['hands'][u]}, room=sid)

    # ② コミュニティを裏向きにリセット
    emit('reset_community', {}, room=room_id)

    # ③ ベット状況リセット通知
    bets_by_sid = {info['sids'][u]: 0 for u in info['players']}
    emit('update_bets', {'bets': bets_by_sid, 'pot': 0}, room=room_id)

    # ④ 新ラウンドの先行プレイヤーへターン開始通知
    info['turn_index'] = 0
    first_uid = info['turn_order'][0]
    emit('turn', {'sid': info['sids'][first_uid]}, room=room_id)

    print(f"[Poker] new round in room {room_id}, turn_order={info['turn_order']}")

# 勝者がポットを請求
@socketio.on('claim_pot', namespace='/poker')
def on_claim_pot(data):
    """
    勝者クライアントから pot 請求があったときにセッションを更新
    data = { amount: number }
    """
    amount = data.get('amount', 0)
    session['money'] = session.get('money', 0) + amount
    session.modified = True
    # 更新後の所持金を当該クライアントへ通知
    emit('update_session_money',
         {'money': session['money']},
         room=request.sid)
@poker_bp.route('/adjust_money', methods=['POST'])
def adjust_money():
    """
    WS で計算した delta（正：加算、負：減算）をクライアントから受けて
    session['money'] に反映し、永続化するエンドポイント
    """
    data   = request.get_json() or {}
    delta  = data.get('delta', 0)
    session['money'] = session.get('money', 0) + delta
    session.modified = True
    return jsonify(money=session['money'])