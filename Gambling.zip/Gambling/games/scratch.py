# games/scratch.py
from flask import Blueprint, render_template, request, session, redirect, url_for, flash
import random
from config import DIFFICULTY_CONFIG, calc_luck

scratch_bp = Blueprint('scratch', __name__, template_folder='../templates/scratch')

# くじ設定（役名 → 賞金）
LOTTERY_PRIZES = {
    'lott_1': 1000,
    'lott_2': 5000,
    'lott_3': 20000,
    'lott_4': 100000,
    'lott_5': 400000,
    'lott_6': 3000000,
    'lott_7': 10000000,
    'lott_8': 60000000,
    'lott_9': 100000000,
    'lott_10': 300000000,
}

# チケット種別 → (名称, cost, 出力範囲)
TICKETS = {
    '10k':  ('1万円', 10000,     list(range(1,  6))),
    '100k': ('100万円', 1000000, list(range(3,  8))),
    '10M':  ('1億円', 100000000, list(range(6, 11))),
}

@scratch_bp.route('/lobby')
def lobby():
    luck = calc_luck()
    odds = DIFFICULTY_CONFIG[session['difficulty']]['odds']
    return render_template(
        'scratch/lobby.html',
        money=session['money'],
        debt=session['debt'],
        luck=luck,
        odds=odds
    )

@scratch_bp.route('/play', methods=['GET', 'POST'])
def play():
    # POST: 「買う」ボタン押下 → 所持金差し引き＋グリッド生成
    if request.method == 'POST':
        ticket = request.form.get('ticket')
        if ticket not in TICKETS:
            flash('不正なチケットです')
            return redirect(url_for('scratch.lobby'))

        name, cost, indices = TICKETS[ticket]
        if session['money'] < cost:
            flash('所持金が足りません')
            return redirect(url_for('scratch.play'))

        # 所持金差し引き
        session['money'] -= cost
        session['scratch_ticket'] = ticket

        # バイアス付き抽選の準備
        luck = calc_luck()  # config.py 側で scratch は最大800にキャップ
        p0    = 1.0 / len(indices)
        alpha = 0.1
        bias  = (luck - 500) / 500.0
        mid   = (len(indices) + 1) / 2  # =3.0 for 5 items

        # 各役の重み計算 & 正規化
        raw = []
        for j in range(len(indices)):
            i = j + 1
            w = p0 + alpha * bias * (i - mid)
            raw.append(max(w, 0.0))
        total   = sum(raw)
        weights = [w / total for w in raw]

        # 3×3 グリッド（9マス）を重み付き抽選
        grid = []
        for _ in range(9):
            choice = random.choices(indices, weights=weights, k=1)[0]
            grid.append(f'lott_{choice}')

        session['scratch_grid']     = grid
        session.pop('scratch_revealed', None)  # クリック状態リセット
        return redirect(url_for('scratch.play'))

    # GET: 初期表示 or 再プレイ
    grid    = session.get('scratch_grid')
    ticket  = session.get('scratch_ticket')
    initial = (grid is None)

    # 初期 or claim 後のアクセスで ticket が無ければ lobby へ
    if initial and ticket not in TICKETS:
        return redirect(url_for('scratch.lobby'))

    # チケット情報から名称・コストを取得
    name, cost, _ = TICKETS[ticket]

    return render_template(
        'scratch/play.html',
        initial=initial,
        ticket=ticket,
        name=name,
        cost=cost,
        grid=grid or [],
        money=session['money'],
        debt=session['debt'],
        luck=calc_luck(),      # テンプレートで運表示したい場合
        odds = DIFFICULTY_CONFIG[session['difficulty']]['odds'],
        prize= LOTTERY_PRIZES,
        logs=session.get('logs', []),
        payout=session.pop('scratch_payout', None),
    )

@scratch_bp.route('/claim', methods=['POST'])
def claim():
    # 既存のグリッドだけクリア、ticket は残す
    grid = session.pop('scratch_grid', None)
    if not grid:
        return redirect(url_for('scratch.play'))

    # チケット情報取得
    ticket = session.get('scratch_ticket')
    _, cost, _ = TICKETS[ticket]

    # まずは縦・横・斜めをチェックして素の払い戻し額を計算
    payout = 0
    # 横
    for r in range(3):
        line = grid[r*3:(r+1)*3]
        if len(set(line)) == 1:
            payout += LOTTERY_PRIZES[line[0]]
    # 縦
    for c in range(3):
        line = [grid[c + i*3] for i in range(3)]
        if len(set(line)) == 1:
            payout += LOTTERY_PRIZES[line[0]]
    # 斜め
    diag1 = [grid[i*4] for i in range(3)]
    diag2 = [grid[(i+1)*2] for i in range(3)]
    if len(set(diag1)) == 1:
        payout += LOTTERY_PRIZES[diag1[0]]
    if len(set(diag2)) == 1:
        payout += LOTTERY_PRIZES[diag2[0]]

    # 難易度倍率を掛ける
    odds = DIFFICULTY_CONFIG[session['difficulty']]['odds']
    payout = int(round(payout * odds))
    session['scratch_payout'] = payout

    # セッションに反映
    net = payout - cost
    session['money'] += payout
    entry = f"{'+' if net>=0 else ''}{net}"
    session['logs'] = [entry] + session.get('logs', [])[:4]

    # クリア／ゲームオーバー判定
    if session['money'] < 1000:
        return redirect(url_for('game_over'))
    if session['money'] >= session['debt']:
        return redirect(url_for('clear'))

    # 再度 play 画面へ（ticket 情報は残るので、再度「買う(¥…)」が表示されます）
    return redirect(url_for('scratch.play'))
