# extensions.py

from flask_socketio import SocketIO

# async_mode は必要に応じて 'eventlet' や 'gevent' に切り替え
socketio = SocketIO(
    cors_allowed_origins="*",
    async_mode="gevent",
    logger=True,
    engineio_logger=True
)
