# app.py

from gevent import monkey
monkey.patch_all()

from flask import Flask, render_template, request, redirect, session, url_for
from flask_session import Session
from extensions import socketio
from config import DIFFICULTY_CONFIG, DIFFICULTY_UNLOCK_COST, GAME_UNLOCK_COST, ITEM_CONFIG, item_config,calc_luck

# Blueprint をインポート
from games.chohan import chohan_bp
from games.highlow import highlow_bp
from games.fx import fx_bp
from games.poker import poker_bp
from games.scratch import scratch_bp

import random
import uuid

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# セッションをサーバーサイド（ファイル）に保存する設定
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = './flask_session/'
app.config['SESSION_PERMANENT'] = False
Session(app)

# Socket.IO を Flask アプリに紐付け
socketio.init_app(app)

# Blueprints 登録
app.register_blueprint(chohan_bp,  url_prefix='/chohan')
app.register_blueprint(highlow_bp, url_prefix='/highlow')
app.register_blueprint(fx_bp,      url_prefix='/fx')
app.register_blueprint(poker_bp,   url_prefix='/poker')
app.register_blueprint(scratch_bp, url_prefix='/scratch')

# ユーザーIDセット（通信用）

@app.before_request
def ensure_user_id():
    if 'user_id' not in session:
        session['user_id'] = str(uuid.uuid4())

# ── 共通ルート ─────────────────────────

@app.route('/')
def title():
    return render_template('title.html')

@app.route('/start', methods=['POST'])
def start():
    session.clear()
    session['debt']       = int(request.form['debt']) * 1_000_000
    session['unlocked']   = {lvl: False for lvl in DIFFICULTY_CONFIG}
    session['unlocked']['easy'] = True
    session['money']      = 0
    session['luck']       = 500
    session['logs']       = []
    session['game']       = 'chohan'
    session['difficulty'] = 'easy'
    return redirect(url_for('create_character'))

@app.route('/create')
def create_character():
    print('\n\n新たなプレイヤーが参加\n\n')
    return render_template('create.html', debt = session['debt'])

@app.route('/create_submit', methods=['POST'])
def create_submit():
    session['money'] = int(request.form['money']) * (10**4)
    session['luck']  = int(request.form['luck'])
    return redirect(url_for('lobby'))

@app.route('/lobby', methods=['GET','POST'])
def lobby():
    session.setdefault('game', 'chohan')
    session.setdefault('difficulty', 'easy')
    if request.method == 'POST':
        session['game']       = request.form['game']
        session['difficulty'] = request.form['difficulty']
    return render_template(
        'lobby.html',
        money=session['money'],
        debt=session['debt'],
        unlocked=session['unlocked'],
        difficulty_config=DIFFICULTY_CONFIG,
        difficulty_unlock_cost=DIFFICULTY_UNLOCK_COST,
        game_unlock_cost=GAME_UNLOCK_COST,
    )

@app.route('/unlock_difficulty', methods=['POST'])
def unlock_difficulty():
    lvl  = request.form['difficulty']
    cost = DIFFICULTY_UNLOCK_COST.get(lvl, 0)
    if (not session['unlocked'].get(lvl)
        and session['money'] >= cost
        and session['money'] - cost >= 1000):
        session['money']        -= cost
        session['unlocked'][lvl] = True
    return redirect(url_for('lobby'))

@app.route('/unlock_game', methods=['POST'])
def unlock_game():
    game = request.form['game']
    cost = GAME_UNLOCK_COST.get(game, 0)
    if (not session['unlocked'].get(game)
        and session['money'] >= cost
        and session['money'] - cost >= 1000):
        session['money']          -= cost
        session['unlocked'][game] = True
    return redirect(url_for('lobby'))

@app.route('/select_game', methods=['POST'])
def select_game():
    session['game']       = request.form['game']
    session['difficulty'] = request.form['difficulty']
    if session['game'] == 'chohan':
        return redirect(url_for('chohan.lobby'))
    if session['game'] == 'highlow':
        return redirect(url_for('highlow.lobby'))
    if session['game'] == 'scratch':
        return redirect(url_for('scratch.lobby'))
    if session['game'] == 'poker':
        return redirect(url_for('poker.lobby'))
    # ここで scratch を拾わないまま、FX へ飛ばしている
    return redirect(url_for('fx.lobby'))

@app.route('/item')
def item():
    value_item = item_config()
    return render_template(
        'item.html',
        money=session['money'],
        debt=session['debt'],
        item_config=value_item
    )

@app.route('/item_buy', methods=['POST'])
def item_buy():
    key = request.form['item']
    # 動的に調整した価格・ボーナスを取得
    adjusted = item_config()
    it = adjusted[key]
    # 購入判定
    if (session['money'] >= it['price']
        and session['money'] - it['price'] >= 1000):
        session['money'] -= it['price']
        session['luck']  += it['bonus']
    return redirect(url_for('item'))

@app.route('/reset')
def reset():
    session.clear()
    return redirect(url_for('title'))

@app.route('/clear')
def clear():
    return render_template('clear.html')

@app.route('/game_over')
def game_over():
    return render_template('game_over.html')

# ─────────────────────────────────────────

if __name__ == '__main__':
    socketio.run(app, host="0.0.0.0", port=9000, debug=True)
