// static/js/poker.js
document.addEventListener('DOMContentLoaded', () => {
  console.log('[Poker] io is', typeof io);

  // ── 0. まず URL から roomId を取り出す ──
  const m = location.pathname.match(/^\/poker\/play\/([^/]+)/);
  const roomId = m ? m[1] : null;
  // ── 1. Socket.IO の接続と全ハンドラ登録 ──
  const socket = io('/poker', {
    transports: ['polling', 'websocket']
  });

  // 1) round_end ではステータスのみ設定
  socket.on('round_end', data => {
    const status = document.getElementById('status');
    if (!status) return;
    console.log('勝敗通知')
    const youWin = (data.winner === socket.id);
    status.textContent = youWin
      ? `あなたの勝ち！ 獲得 ${data.amount} 円`
      : `あなたの負け… 相手が ${data.amount} 円 獲得`;
    // ボタン表示はサーバーの show_round_buttons_* を待つ
    // ── 勝者なら即座に pot を請求 ──
    if (youWin) {
      socket.emit('claim_pot', { amount: data.amount });
    }
  });

  // プレイ画面：直前アクション表示 & コール判定
  socket.on('opponent_action', data => {
    const action_status = document.getElementById('action_status');
    if (!action_status) return;
    let msg;
    if (data.action === 'raise') {
      msg = '相手がレイズしました';
    } else if (data.action === 'call') {
      msg = '相手がコールしました';
    } else if (data.action === 'check') {
      msg = '相手がチェックしました';
    } else {
      msg = '相手がフォールドしました';
    }
    action_status.textContent = msg;
    // ボタンラベルも連動（既に実装済み）
    const checkBtn = document.getElementById('btn-check');
    if (checkBtn) {
      checkBtn.textContent = (data.action === 'raise') ? 'コール' : 'チェック';
    }
  });

  // 共通接続ログ
  socket.on('connect', () => {
    console.log('[Poker] connected ➞', socket.id);
    // ホスト待機ページなら再参加
    const waitMatch = window.location.pathname.match(/^\/poker\/wait\/([^/]+)/);
    if (waitMatch) {
      const roomId = waitMatch[1];
      console.log('[Poker] host_rejoin ➞', roomId);
      socket.emit('host_rejoin', { room_id: roomId });
    }
  });
  socket.on('connect_error', err => {
    console.error('[Poker] connect_error ➞', err);
  });
  socket.on('disconnect', reason => {
    console.log('[Poker] disconnected ➞', reason);
  });

  // ロビー画面：ホスト作成
  const createBtn = document.getElementById('create-room');
  if (createBtn) {
    console.log('[Poker] #create-room button found');
    createBtn.addEventListener('click', () => {
      console.log('[Poker] Emitting create_room');
      socket.emit('create_room', {});
    });
  }

  // ロビー画面：ゲスト参加
  document.querySelectorAll('.join-room').forEach(btn => {
    btn.addEventListener('click', () => {
      const room = btn.dataset.room;
      console.log('[Poker] Emitting join_room to', room);
      socket.emit('join_room', { room_id: room });
    });
  });

  // 新規ルーム作成 → 待機画面へ
  socket.on('room_created', data => {
    console.log('[Poker] room_created ➞', data);
    window.location.href = `/poker/wait/${data.room_id}`;
  });

  // matched → Play 画面へ遷移
  socket.on('matched', data => {
    location.href = `/poker/play/${data.room_id}`;
    console.log('[Poker] matched ➞', data);
  });

  // ■ ホールカード受け取り（プレイ画面だけ）
  socket.on('deal_hole', data => {
    console.log('[Poker] deal_hole ➞', data.hole_cards);
    const c0 = document.getElementById('my-card-0');
    const c1 = document.getElementById('my-card-1');
    console.log('c0=', c0, 'c1=', c1);
    if (c0 && c1) {
      c0.src = `/static/img/card/${data.hole_cards[0]}.png`;
      c1.src = `/static/img/card/${data.hole_cards[1]}.png`;
      console.log('[Poker] cards set:', c0.src, c1.src);
    }
  });

  // play.html 側で
  window.addEventListener('DOMContentLoaded', () => {
    const m = location.pathname.match(/^\/poker\/play\/([^/]+)/);
    if (m) {
      const roomId = m[1];
      console.log('[Poker] play → join_room', roomId);
      console.log('[Poker] 2回目です', roomId);
      socket.emit('join_room', { room_id: roomId });
    }
  });

  socket.on('turn', data => {
    const isMyTurn = (data.sid === socket.id);
    console.log(data.sid)
    console.log(socket.id)
    // ステータス表示
    const st = document.getElementById('status');
    if (st) st.textContent = isMyTurn ? 'あなたのターンです' : '相手のターン…';
    console.log('ターン通知')
    // ボタンの有効/無効を切り替え
    ['btn-fold', 'btn-check', 'btn-raise'].forEach(id => {
      const btn = document.getElementById(id);
      if (btn) btn.disabled = !isMyTurn;
    });
  });

  // プレイ画面：ベット更新
  socket.on('update_bets', data => {
    const myBet = document.getElementById('my-bet');
    const oppBet = document.getElementById('opponent-bet');
    const pot = document.getElementById('pot');
    if (myBet && oppBet && pot) {
      myBet.textContent = `自分のベット：${data.bets[socket.id]} 円`;
      const other = Object.keys(data.bets).find(id => id !== socket.id);
      oppBet.textContent = `相手のベット：${data.bets[other]} 円`;
      pot.textContent = `ポット：${data.pot} 円`;
    }
  });

  // 所持金更新を受け取って画面を書き換え
  socket.on('update_session_money', data => {
    const el = document.getElementById('my-money');
    if (el) el.textContent = data.money;
  });

  // プレイ画面：コミュニティ開示
  socket.on('reveal', data => {
    data.cards.forEach((c, i) => {
      const img = document.getElementById(`comm-${i}`);
      if (img) img.src = `/static/img/card/${c}.png`;
    });
    // サイクル更新（reveal）が起こったら、チェックボタンを「チェック」に戻す
    const checkBtn = document.getElementById('btn-check');
    if (checkBtn) checkBtn.textContent = 'チェック';
  });

  // プレイ画面：ショーダウン
  socket.on('showdown', data => {
    const imgs = document.querySelectorAll('#opponent-hand img');
    if (imgs.length === 2) {
      imgs[0].src = `/static/img/card/${data.opponent_hole[0]}.png`;
      imgs[1].src = `/static/img/card/${data.opponent_hole[1]}.png`;
    }
    // 役名表示
    const status = document.getElementById('action_status');
    if (status) {
      console.log('役判定')
      status.textContent = `自分：${data.self_hand}　相手：${data.opponent_hand}`;
    }
  });

  // ① money_delta（チェック・レイズ分の減少）受信時
  socket.on('money_delta', data => {
    const delta = data.delta;  // たとえば -1000
    fetch('/poker/adjust_money', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ delta })
    })
      .then(res => res.json())
      .then(json => {
        // 更新された所持金を反映
        const el = document.getElementById('my-money');
        if (el) el.textContent = json.money;
      });
  });



  // 2) Loser にだけ送られてくる → Loser画面にのみボタンを出す
  socket.on('show_round_buttons_loser', () => {
    const actions = document.getElementById('actions');
    actions.innerHTML = `
    <button id="btn-continue">続ける</button>
    <button id="btn-exit">退出する</button>`;
    document.getElementById('btn-continue').onclick = () => {
      // Loser が OK を押したらサーバーに通知
      socket.emit('loser_ready', { room_id: roomId });
      // 自分はもう押せないようクリア
      actions.innerHTML = '';
    };
    document.getElementById('btn-exit').onclick = () => {
      console.log('退出')
      socket.emit('exit_round', { room_id: roomId });
    };
  });

  // 3) Winner にだけ送られてくる → Winner画面にのみボタンを出す
  socket.on('show_round_buttons_winner', () => {
    const actions = document.getElementById('actions');
    actions.innerHTML = `
    <button id="btn-continue">続ける</button>
    <button id="btn-exit">退出する</button>`;
    document.getElementById('btn-continue').onclick = () => {
      // Winner が続けるを押すと new_round を発火
      socket.emit('new_round', { room_id: roomId });
      actions.innerHTML = '';
    };
    document.getElementById('btn-exit').onclick = () => {
      socket.emit('exit_round', { room_id: roomId });
    };
  });

  // 4) 退出命令 → 全員ロビーへ
  socket.on('force_exit', () => {
    window.location.href = '/poker/lobby';

  });



  // ■ 再度アクションボタン群にハンドラを登録するヘルパー
  function attachActionHandlers() {
    document.getElementById('btn-fold')
      .addEventListener('click', () => {
        socket.emit('action', { room_id: roomId, action: 'fold' });
        console.log('[Poker] fold');
      });
    document.getElementById('btn-check')
      .addEventListener('click', () => {
        socket.emit('action', { room_id: roomId, action: 'check' });
        console.log('[Poker] check');
      });
    document.getElementById('btn-raise')
      .addEventListener('click', () => {
        socket.emit('action', { room_id: roomId, action: 'raise' });
        console.log('[Poker] raise');
      });
  }
  // 初回ロード時にも登録
  attachActionHandlers();
  // ■ コミュニティカードを裏向きにリセット
  socket.on('reset_community', () => {
    // コミュニティ
    document.querySelectorAll('#community img').forEach(img => {
      img.src = '/static/img/card/back.png';
    });
    // 相手ホールも裏向きに戻す
    document.querySelectorAll('#opponent-hand img').forEach(img => {
      img.src = '/static/img/card/back.png';
    });
    // ベット・ステータスは update_bets, turn イベントで更新されるのでここではクリアしない
    const checkBtn = document.getElementById('btn-check');
    if (checkBtn) checkBtn.textContent = 'チェック';
  });
});
