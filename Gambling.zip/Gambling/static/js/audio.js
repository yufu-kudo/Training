// static/js/audio.js
document.addEventListener('DOMContentLoaded', () => {
  const bgm = document.getElementById('bgm');
  if (!bgm) return;

  // ── 再生位置復元 ──
  const savedTime = localStorage.getItem('bgmTime');
  if (savedTime !== null) {
    bgm.currentTime = parseFloat(savedTime);
  }

  // ── 音量復元 ──
  const savedBgmVol = localStorage.getItem('bgmVolume');
  bgm.volume = savedBgmVol !== null
    ? parseFloat(savedBgmVol)
    : 0.5;  // デフォルト 50%

  // ── SFX 音量復元 ──
  const savedSfxVol = localStorage.getItem('sfxVolume');
  let sfxVolume = savedSfxVol !== null
    ? parseFloat(savedSfxVol)
    : 0.5;  // デフォルト 50%

  // スライダー設定（HTML に <input id="sfx-volume"> を用意してください）
  const sfxSlider = document.getElementById('sfx-volume');
  if (sfxSlider) {
    sfxSlider.value = sfxVolume;
    sfxSlider.addEventListener('input', e => {
      sfxVolume = parseFloat(e.target.value);
      localStorage.setItem('sfxVolume', sfxVolume);
    });
  }

  // スライダーで調節できるように設定（HTML 側に id="bgm-volume" の input を用意）
  const volumeSlider = document.getElementById('bgm-volume');
  if (volumeSlider) {
    volumeSlider.value = bgm.volume;
    volumeSlider.addEventListener('input', e => {
      const vol = parseFloat(e.target.value);
      bgm.volume = vol;
      localStorage.setItem('bgmVolume', vol);
    });
  }

  // ── 自動再生＆フォールバック ──
  bgm.loop = true;
  bgm.preload = 'auto';
  bgm.play().catch(() => {
    const resumeOnClick = () => {
      bgm.play();
      document.removeEventListener('click', resumeOnClick);
    };
    document.addEventListener('click', resumeOnClick);
  });

  // ── ページ離脱時に再生位置を保存 ──
  window.addEventListener('beforeunload', () => {
    localStorage.setItem('bgmTime', bgm.currentTime);
  });

  // ── (A) ページ固有SFX が定義されていればそれだけ再生して終了 ──
  if (typeof PAGE_SFX !== 'undefined') {
    const pageAudio = new Audio(PAGE_SFX);
    pageAudio.volume = sfxVolume;             // ← ここで音量を適用
    pageAudio.play().catch(err => {
      console.error('ページ固有SFX再生失敗:', err);
    });
    return;
  }

  // ── 1) 各クラスのボタンに click イベントを登録 ──
  Object.entries(SFX_SOURCES).forEach(([cls, src]) => {
    document.querySelectorAll(`.${cls}`).forEach(btn => {
      btn.addEventListener('click', () => {
        // クリックされたボタンに対応する音声ファイルを保存
        sessionStorage.setItem('pending_sfx', src);
        // 通常のフォーム送信やリンク遷移はそのまま行われる
      });
    });
  });

  // ── 2) ページ読み込み後に一度だけ再生 ──
  const pendingSrc = sessionStorage.getItem('pending_sfx');
  if (pendingSrc) {
    sessionStorage.removeItem('pending_sfx');
    const audio = new Audio(pendingSrc);
    audio.volume = sfxVolume;                 // ← ここで音量を適用
    audio.play().catch(err => {
      console.error('SFX 再生に失敗:', err);
    });
  }
});
