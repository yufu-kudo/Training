// static/js/script.js

(function() {
  /**
   * ヘッダーの .money と .menu-buttons が重なっているか判定し、
   * 重なっていればメニューを「アイテム」ボタンだけに差し替え、
   * 重なっていなければ元のボタン構成に戻す。
   */
  function checkHeaderOverlap() {
    const moneyEl = document.querySelector('.sticky-header .money');
    const menuEl  = document.querySelector('.sticky-header .menu-buttons');
    if (!moneyEl || !menuEl) return;

    const r1 = moneyEl.getBoundingClientRect();
    const r2 = menuEl .getBoundingClientRect();

    // どこか1点でも離れていれば overlap=false
    const overlap = !(
      r1.right  < r2.left  ||
      r1.left   > r2.right ||
      r1.bottom < r2.top   ||
      r1.top    > r2.bottom
    );

    if (overlap) {
      menuEl.innerHTML = `
        <a href="${window.location.origin + '/item'}" class="location_button">アイテム</a>
      `;
    } else {
      menuEl.innerHTML = `
        <a href="${window.location.origin + '/item'}" class="location_button">アイテム購入</a>
        <button onclick="confirmReset()" class="reset_button" id="reset-button">人生をやり直す</button>
      `;
    }
  }

  // ページ読み込み時・リサイズ時に実行
  window.addEventListener('DOMContentLoaded', checkHeaderOverlap);
  window.addEventListener('resize',          checkHeaderOverlap);
})();
